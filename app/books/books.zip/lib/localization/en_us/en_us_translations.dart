final Map<String, String> enUs = {
  'msg_network_err': 'Network Error',
  'msg_something_went_wrong': 'Something Went Wrong!',
  "msg_check_your_app_s":
      "Check your app's UI from the below demo screens of your app.",
  "lbl_sign_in": "sign in",
  "msg_iphone_13_pro_max2": "iPhone 13 Pro Max - Four",
  "msg_already_have_account": "Already have account? ",
  "lbl": "******",
  "lbl_email_address": "Email Address",
  "lbl_app_navigation": "App Navigation",
  "msg_iphone_13_pro_max": "iPhone 13 Pro Max - Three",
  "lbl_relax_and_read": "Relax And Read",
  "lbl_sign_up": "Sign up",
  "lbl_create_account": "Create Account"
};
