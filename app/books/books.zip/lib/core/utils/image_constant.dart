class ImageConstant {
  static String imgLock = 'assets/images/img_lock.svg';

  static String imgSaly16 = 'assets/images/img_saly16.png';

  static String imgMail = 'assets/images/img_mail.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
